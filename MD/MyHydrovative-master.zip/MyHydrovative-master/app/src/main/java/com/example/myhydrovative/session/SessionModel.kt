package com.example.myhydrovative.session

class SessionModel (
    val name: String,
    val token: String,
    val isLogin: Boolean
)